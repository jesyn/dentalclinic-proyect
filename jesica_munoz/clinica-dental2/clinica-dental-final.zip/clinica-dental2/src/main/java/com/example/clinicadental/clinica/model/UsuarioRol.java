package com.example.clinicadental.clinica.model;


public enum UsuarioRol {
    USER, ADMIN

}

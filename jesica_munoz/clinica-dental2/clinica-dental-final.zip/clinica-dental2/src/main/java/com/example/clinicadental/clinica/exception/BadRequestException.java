package com.example.clinicadental.clinica.exception;

public class BadRequestException extends Exception{

    public BadRequestException(String message) {
        super(message);
    }
}

